import { ProductDetailType } from "@/lib/type/product";

export const dummyProductList = [
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
    {
        id: 1,
        name: "Very cool anime keyboard",
        description: null,
        price: 910000,
        category: [
            {
                id: 1,
                label: "Electronic",
                value: "electronic"
            }
        ]
    },
    {
        id: 2,
        name: "Cute Action Figure",
        description: null,
        price: 75000,
        category: [
            {
                id: 2,
                label: "Entertainment",
                value: "entertainment"
            }
        ]
    },
    {
        id: 3,
        name: "Microsoft Office",
        description: null,
        price: 100000,
        category: [
            {
                id: 3,
                label: "software",
                value: "software"
            }
        ]
    },
] satisfies ProductDetailType[]